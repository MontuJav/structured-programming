#include <stdio.h> //Incluimos la libreria stdio.h

void main(void){ //La funcion main no devuelve nada y recibe nada
	printf("Hola a todos\n"); //Salida de pantalla
	return; //No regresamos nada
}