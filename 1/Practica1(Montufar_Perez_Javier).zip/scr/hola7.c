#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("%s %s\n", "Hola a", "todos");
	return 0;
}