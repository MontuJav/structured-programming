#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	char* mensaje="Hola a todos\n";
	printf(mensaje); //No es necesario poner %s, mensaje.
	return 0;
}