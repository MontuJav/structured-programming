#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	;;;;
	return printf("Hola a todos");
}