#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	char* mensaje= "Hola a todos"; //Forma alterna de 'declarar' una cadena
	printf("%s\n", mensaje);
	return 0;
}