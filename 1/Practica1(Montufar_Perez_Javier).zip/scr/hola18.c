#include <stdio.h> //Incluimos la libreria stdio.h

void main(){
	printf("Hola a todos\0nada"); //Todo lo que esta despues de '\' lo ignora
}