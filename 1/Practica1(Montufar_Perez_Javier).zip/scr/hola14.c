#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("Hola\
 a \
todos\n");
	return 0;
}