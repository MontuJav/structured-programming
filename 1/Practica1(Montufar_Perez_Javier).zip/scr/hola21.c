#include <stdio.h> //Incluimos la libreria stdio.h
#define MENSAJE "Hola a todos\n" //Define es una instruccion del preprocesador


main(){
	printf(MENSAJE);
	return 0;
}