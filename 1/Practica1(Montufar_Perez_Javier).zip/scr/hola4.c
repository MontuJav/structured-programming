#include <stdio.h> //Incluimos la libreria stdio.h

int main(int argc, char* argv[]){
	printf("Hola a todos \n");
	return 0;
}