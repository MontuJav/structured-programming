#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("%s%c","Hola a \
todos",'\n'); //'\' sirve para hacer salto de linea
	return 0;
}