#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("%s", "Hola a todos\n"); //%s indica que se pone una cadena en ese lugar de la cadena
	return 0;
}