#include <stdio.h> //Incluimos la libreria stdio.h
#define MENSAJE "Hola %s\n"

int main(){
	printf(MENSAJE, "a todos");
	return 0;
}