#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("Hola a todos",
			"Nada más"); //Salto de linea
	return 0;
}