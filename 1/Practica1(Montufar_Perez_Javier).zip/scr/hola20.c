#include <stdio.h> //Incluimos la libreria stdio.h

main(){
	printf("%s a %s\n",
			"Hola","todos");
	return 0;
}