#include <stdio.h> //Incluimos la libreria stdio.h

int main(){ //La funcion main devolvera un entero
	printf("Hola a todos\n"); //Salida de pantalla
	return 0; //Regresamos un 0 a la funcion main
}