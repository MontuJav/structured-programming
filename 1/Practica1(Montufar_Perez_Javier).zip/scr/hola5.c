#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("Hola %c todos\n", 'a'); //%c indica que se pondra un char en ese lugar de la cadena
	return 0;
}