#include <stdio.h> //Incluimos la libreria stdio.h
#define MENSAJE "Hola a todos\n"

int main(int argc, char* argv[]){
	printf(MENSAJE);
	return 0;
}
