#include <stdio.h> //Incluimos la libreria stdio.h

int main(){
	printf("\x48\x6F\x6C\x61\x20\x61\
\x20\x74\x6F\x64\x6F\x73\n"); //Escribir todo en ASCII es igual que hacerlo con letras
	return 0;
}