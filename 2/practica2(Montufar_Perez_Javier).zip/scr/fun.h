/*
Prototipo.
*/

#ifndef FUN_H
#define FUN_H

void swap1( char* a, char* b, char* c, char* d, char* e);
void swap2( char* a, char* b, char* c, char* d, char* e);
void swap3( char* a, char* b, char* c, char* d, char* e);
void swap4( char* a, char* b, char* c, char* d, char* e);

#endif